.MetaPsi <- function(r,
                     psi_diag,
                     psi_d_free,
                     psi_d_values,
                     psi_d_lbound,
                     psi_d_ubound,
                     psi_l_free,
                     psi_l_values,
                     psi_l_lbound,
                     psi_l_ubound,
                     alpha) {
  idx <- seq_len(r)
  if (psi_diag) {
    out <- .MetaPsiDiag(
      r = r,
      idx = idx,
      psi_d_free = psi_d_free,
      psi_d_values = psi_d_values,
      psi_d_lbound = psi_d_lbound,
      psi_d_ubound = psi_d_ubound,
      psi_d_equal = FALSE,
      alpha = alpha
    )
  } else {
    out <- .MetaPsiSym(
      r = r,
      idx = idx,
      psi_d_free = psi_d_free,
      psi_d_values = psi_d_values,
      psi_d_lbound = psi_d_lbound,
      psi_d_ubound = psi_d_ubound,
      psi_l_free = psi_l_free,
      psi_l_values = psi_l_values,
      psi_l_lbound = psi_l_lbound,
      psi_l_ubound = psi_l_ubound,
      psi_d_equal = FALSE,
      alpha = alpha
    )
  }
  out
}
